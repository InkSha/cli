# My-Cli

My CLI.

## Feature

### init project

select need project template then init project and init git store.

- package and library project template

TODO:

- nest backend project template
- other front template

### add project configure

toggle to current project, exec cli command.

TODO:

- i18n
- state manager
- api
- ...

### small utils

TODO:

- quick simple server
- todo memo
